package com.example.rlaxotlr

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Custom(val custom_ex : Exercise_kind, val Custom_name: String): Parcelable